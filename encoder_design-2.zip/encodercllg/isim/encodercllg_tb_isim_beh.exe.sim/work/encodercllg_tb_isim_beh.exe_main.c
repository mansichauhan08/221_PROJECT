/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_2592010699;
char *STD_STANDARD;
char *IEEE_P_1242562249;
char *IEEE_P_3499444699;
char *IEEE_P_3620187407;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    ieee_p_1242562249_init();
    ieee_p_3499444699_init();
    ieee_p_3620187407_init();
    work_a_0661580443_3212880686_init();
    work_a_1233146073_2526369337_init();
    work_a_3558894211_3212880686_init();
    work_a_3459228015_3212880686_init();
    work_a_1942683869_3212880686_init();
    work_a_1246116888_3212880686_init();
    work_a_1879927836_2526369337_init();
    work_a_3351764515_3212880686_init();
    work_a_3441104492_3212880686_init();
    work_a_3905495149_3212880686_init();
    work_a_2057242038_1200379466_init();
    work_a_2672350652_3212880686_init();
    work_a_1508711817_3212880686_init();
    work_a_2797988217_3212880686_init();
    work_a_1616912716_3212880686_init();
    work_a_0247577422_3212880686_init();
    work_a_0995743634_3212880686_init();
    work_a_4261158823_3212880686_init();
    work_a_3802735638_3212880686_init();
    work_a_2479774264_3212880686_init();
    work_a_1689261214_3212880686_init();
    work_a_1735817311_2526369337_init();
    work_a_4266320614_3212880686_init();
    work_a_0013728087_3212880686_init();
    work_a_0051844502_2526369337_init();
    work_a_3912365733_3212880686_init();
    work_a_1755156827_1200379466_init();
    work_a_4275376173_1200379466_init();
    work_a_1360047518_2762913819_init();
    work_a_0308474336_1200379466_init();
    work_a_0290344353_1200379466_init();
    work_a_3763881202_1200379466_init();
    work_a_1003049348_2372691052_init();


    xsi_register_tops("work_a_1003049348_2372691052");

    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    IEEE_P_3620187407 = xsi_get_engine_memory("ieee_p_3620187407");

    return xsi_run_simulation(argc, argv);

}
