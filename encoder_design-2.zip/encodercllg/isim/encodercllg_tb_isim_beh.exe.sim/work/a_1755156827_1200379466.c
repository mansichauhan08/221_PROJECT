/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "H:/D DRIVE/encodercllg/encoder1.vhd";
extern char *IEEE_P_2592010699;



static void work_a_1755156827_1200379466_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned char t21;
    char *t22;
    char *t23;
    unsigned char t25;
    unsigned int t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned char t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned char t41;
    unsigned char t42;
    char *t43;
    char *t44;
    char *t46;
    unsigned char t47;
    char *t48;
    char *t49;
    char *t51;
    unsigned char t52;
    unsigned char t53;
    char *t54;
    char *t55;
    char *t57;
    unsigned char t58;
    char *t59;
    char *t60;
    char *t62;
    unsigned char t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    unsigned char t69;
    unsigned char t70;
    char *t71;
    char *t72;
    char *t74;
    unsigned char t75;
    char *t76;
    char *t77;
    char *t79;
    unsigned char t80;
    unsigned char t81;
    char *t82;
    char *t83;
    char *t85;
    unsigned char t86;
    char *t87;
    char *t88;
    char *t90;
    unsigned char t91;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    char *t101;
    char *t102;

LAB0:    xsi_set_current_line(895, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 4478);
    t5 = 1;
    if (9U == 9U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t22 = (t0 + 1032U);
    t23 = *((char **)t22);
    t22 = (t0 + 4496);
    t25 = 1;
    if (9U == 9U)
        goto LAB25;

LAB26:    t25 = 0;

LAB27:    if (t25 == 1)
        goto LAB22;

LAB23:    t21 = (unsigned char)0;

LAB24:    if (t21 != 0)
        goto LAB20;

LAB21:    t43 = (t0 + 1032U);
    t44 = *((char **)t43);
    t43 = (t0 + 4514);
    t46 = ((IEEE_P_2592010699) + 4024);
    t47 = xsi_vhdl_greater(t46, t44, 9U, t43, 9U);
    if (t47 == 1)
        goto LAB42;

LAB43:    t42 = (unsigned char)0;

LAB44:    if (t42 == 1)
        goto LAB39;

LAB40:    t41 = (unsigned char)0;

LAB41:    if (t41 != 0)
        goto LAB37;

LAB38:    t71 = (t0 + 1032U);
    t72 = *((char **)t71);
    t71 = (t0 + 4550);
    t74 = ((IEEE_P_2592010699) + 4024);
    t75 = xsi_vhdl_lessthan(t74, t72, 9U, t71, 9U);
    if (t75 == 1)
        goto LAB53;

LAB54:    t70 = (unsigned char)0;

LAB55:    if (t70 == 1)
        goto LAB50;

LAB51:    t69 = (unsigned char)0;

LAB52:    if (t69 != 0)
        goto LAB48;

LAB49:
LAB59:    t97 = (t0 + 2912);
    t98 = (t97 + 56U);
    t99 = *((char **)t98);
    t100 = (t99 + 56U);
    t101 = *((char **)t100);
    *((unsigned char *)t101) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t97);

LAB2:    t102 = (t0 + 2832);
    *((int *)t102) = 1;

LAB1:    return;
LAB3:    t16 = (t0 + 2912);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t16);
    goto LAB2;

LAB5:    t9 = (t0 + 1192U);
    t10 = *((char **)t9);
    t9 = (t0 + 4487);
    t12 = 1;
    if (9U == 9U)
        goto LAB14;

LAB15:    t12 = 0;

LAB16:    t1 = t12;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 9U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t13 = 0;

LAB17:    if (t13 < 9U)
        goto LAB18;
    else
        goto LAB16;

LAB18:    t14 = (t10 + t13);
    t15 = (t9 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB15;

LAB19:    t13 = (t13 + 1);
    goto LAB17;

LAB20:    t36 = (t0 + 2912);
    t37 = (t36 + 56U);
    t38 = *((char **)t37);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    *((unsigned char *)t40) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t36);
    goto LAB2;

LAB22:    t29 = (t0 + 1192U);
    t30 = *((char **)t29);
    t29 = (t0 + 4505);
    t32 = 1;
    if (9U == 9U)
        goto LAB31;

LAB32:    t32 = 0;

LAB33:    t21 = t32;
    goto LAB24;

LAB25:    t26 = 0;

LAB28:    if (t26 < 9U)
        goto LAB29;
    else
        goto LAB27;

LAB29:    t27 = (t23 + t26);
    t28 = (t22 + t26);
    if (*((unsigned char *)t27) != *((unsigned char *)t28))
        goto LAB26;

LAB30:    t26 = (t26 + 1);
    goto LAB28;

LAB31:    t33 = 0;

LAB34:    if (t33 < 9U)
        goto LAB35;
    else
        goto LAB33;

LAB35:    t34 = (t30 + t33);
    t35 = (t29 + t33);
    if (*((unsigned char *)t34) != *((unsigned char *)t35))
        goto LAB32;

LAB36:    t33 = (t33 + 1);
    goto LAB34;

LAB37:    t64 = (t0 + 2912);
    t65 = (t64 + 56U);
    t66 = *((char **)t65);
    t67 = (t66 + 56U);
    t68 = *((char **)t67);
    *((unsigned char *)t68) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t64);
    goto LAB2;

LAB39:    t54 = (t0 + 1192U);
    t55 = *((char **)t54);
    t54 = (t0 + 4532);
    t57 = ((IEEE_P_2592010699) + 4024);
    t58 = xsi_vhdl_greater(t57, t55, 9U, t54, 9U);
    if (t58 == 1)
        goto LAB45;

LAB46:    t53 = (unsigned char)0;

LAB47:    t41 = t53;
    goto LAB41;

LAB42:    t48 = (t0 + 1032U);
    t49 = *((char **)t48);
    t48 = (t0 + 4523);
    t51 = ((IEEE_P_2592010699) + 4024);
    t52 = xsi_vhdl_lessthan(t51, t49, 9U, t48, 9U);
    t42 = t52;
    goto LAB44;

LAB45:    t59 = (t0 + 1192U);
    t60 = *((char **)t59);
    t59 = (t0 + 4541);
    t62 = ((IEEE_P_2592010699) + 4024);
    t63 = xsi_vhdl_lessthan(t62, t60, 9U, t59, 9U);
    t53 = t63;
    goto LAB47;

LAB48:    t92 = (t0 + 2912);
    t93 = (t92 + 56U);
    t94 = *((char **)t93);
    t95 = (t94 + 56U);
    t96 = *((char **)t95);
    *((unsigned char *)t96) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t92);
    goto LAB2;

LAB50:    t82 = (t0 + 1192U);
    t83 = *((char **)t82);
    t82 = (t0 + 4568);
    t85 = ((IEEE_P_2592010699) + 4024);
    t86 = xsi_vhdl_lessthan(t85, t83, 9U, t82, 9U);
    if (t86 == 1)
        goto LAB56;

LAB57:    t81 = (unsigned char)0;

LAB58:    t69 = t81;
    goto LAB52;

LAB53:    t76 = (t0 + 1032U);
    t77 = *((char **)t76);
    t76 = (t0 + 4559);
    t79 = ((IEEE_P_2592010699) + 4024);
    t80 = xsi_vhdl_greater(t79, t77, 9U, t76, 9U);
    t70 = t80;
    goto LAB55;

LAB56:    t87 = (t0 + 1192U);
    t88 = *((char **)t87);
    t87 = (t0 + 4577);
    t90 = ((IEEE_P_2592010699) + 4024);
    t91 = xsi_vhdl_greater(t90, t88, 9U, t87, 9U);
    t81 = t91;
    goto LAB58;

LAB60:    goto LAB2;

}


extern void work_a_1755156827_1200379466_init()
{
	static char *pe[] = {(void *)work_a_1755156827_1200379466_p_0};
	xsi_register_didat("work_a_1755156827_1200379466", "isim/encodercllg_tb_isim_beh.exe.sim/work/a_1755156827_1200379466.didat");
	xsi_register_executes(pe);
}
