/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "H:/D DRIVE/encodercllg/encodercllg_tb.vhd";



static void work_a_1003049348_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int64 t4;
    char *t5;
    char *t6;
    char *t7;
    int64 t8;

LAB0:    t1 = (t0 + 4792U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(133, ng0);
    t2 = (t0 + 3328U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t2 = (t0 + 4600);
    xsi_process_wait(t2, t4);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(134, ng0);

LAB8:
LAB9:    xsi_set_current_line(135, ng0);
    t2 = (t0 + 5424);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 3088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t8 = (t4 / 2);
    t2 = (t0 + 4600);
    xsi_process_wait(t2, t8);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB10:;
LAB11:    goto LAB2;

LAB12:    xsi_set_current_line(137, ng0);
    t2 = (t0 + 5424);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(138, ng0);
    t2 = (t0 + 3088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t8 = (t4 / 2);
    t2 = (t0 + 4600);
    xsi_process_wait(t2, t8);

LAB18:    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

LAB16:    goto LAB8;

LAB17:    goto LAB16;

LAB19:    goto LAB17;

}

static void work_a_1003049348_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    int t5;
    int t6;
    char *t7;
    char *t8;
    int t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;

LAB0:    t1 = (t0 + 5040U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(149, ng0);
    t3 = (85 * 1000LL);
    t2 = (t0 + 4848);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(150, ng0);
    t3 = (200 * 1000LL);
    t2 = (t0 + 4848);
    xsi_process_wait(t2, t3);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(151, ng0);
    t2 = (t0 + 9632);
    *((int *)t2) = 0;
    t4 = (t0 + 9636);
    *((int *)t4) = 7;
    t5 = 0;
    t6 = 7;

LAB12:    if (t5 <= t6)
        goto LAB13;

LAB15:    xsi_set_current_line(182, ng0);
    if ((unsigned char)0 == 0)
        goto LAB55;

LAB56:    xsi_set_current_line(183, ng0);

LAB59:    *((char **)t1) = &&LAB60;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB13:    xsi_set_current_line(152, ng0);
    t7 = (t0 + 3688U);
    t8 = *((char **)t7);
    t7 = (t0 + 9632);
    t9 = *((int *)t7);
    t10 = (t9 - 0);
    t11 = (t10 * 1);
    t12 = (40U * t11);
    t13 = (0 + t12);
    t14 = (t8 + t13);
    t15 = (t0 + 3808U);
    t16 = *((char **)t15);
    t15 = (t16 + 0);
    memcpy(t15, t14, 40U);
    xsi_set_current_line(153, ng0);
    t2 = (t0 + 5488);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t14 = *((char **)t8);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(154, ng0);
    t2 = (t0 + 3808U);
    t4 = *((char **)t2);
    t11 = (0 + 0U);
    t2 = (t4 + t11);
    t7 = (t0 + 5552);
    t8 = (t7 + 56U);
    t14 = *((char **)t8);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t2, 8U);
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(155, ng0);
    t2 = (t0 + 3808U);
    t4 = *((char **)t2);
    t11 = (0 + 8U);
    t2 = (t4 + t11);
    t7 = (t0 + 5616);
    t8 = (t7 + 56U);
    t14 = *((char **)t8);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t2, 8U);
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(156, ng0);
    t2 = (t0 + 3808U);
    t4 = *((char **)t2);
    t11 = (0 + 16U);
    t2 = (t4 + t11);
    t17 = *((unsigned char *)t2);
    t7 = (t0 + 5680);
    t8 = (t7 + 56U);
    t14 = *((char **)t8);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = t17;
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(157, ng0);
    t3 = (200 * 1000LL);
    t2 = (t0 + 4848);
    xsi_process_wait(t2, t3);

LAB18:    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB14:    t2 = (t0 + 9632);
    t5 = *((int *)t2);
    t4 = (t0 + 9636);
    t6 = *((int *)t4);
    if (t5 == t6)
        goto LAB15;

LAB54:    t9 = (t5 + 1);
    t5 = t9;
    t7 = (t0 + 9632);
    *((int *)t7) = t5;
    goto LAB12;

LAB16:    xsi_set_current_line(158, ng0);
    t3 = (2230 * 1000LL);
    t2 = (t0 + 4848);
    xsi_process_wait(t2, t3);

LAB22:    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB17:    goto LAB16;

LAB19:    goto LAB17;

LAB20:    xsi_set_current_line(159, ng0);
    t2 = (t0 + 1832U);
    t4 = *((char **)t2);
    t2 = (t0 + 3808U);
    t7 = *((char **)t2);
    t11 = (0 + 17U);
    t2 = (t7 + t11);
    t17 = 1;
    if (8U == 8U)
        goto LAB26;

LAB27:    t17 = 0;

LAB28:    if (t17 == 0)
        goto LAB24;

LAB25:    xsi_set_current_line(160, ng0);
    t2 = (t0 + 9660);
    xsi_report(t2, 25U, (unsigned char)0);
    xsi_set_current_line(162, ng0);
    t2 = (t0 + 1992U);
    t4 = *((char **)t2);
    t2 = (t0 + 3808U);
    t7 = *((char **)t2);
    t11 = (0 + 25U);
    t2 = (t7 + t11);
    t17 = 1;
    if (8U == 8U)
        goto LAB34;

LAB35:    t17 = 0;

LAB36:    if (t17 == 0)
        goto LAB32;

LAB33:    xsi_set_current_line(163, ng0);
    t2 = (t0 + 9705);
    xsi_report(t2, 25U, (unsigned char)0);
    xsi_set_current_line(165, ng0);
    t2 = (t0 + 2152U);
    t4 = *((char **)t2);
    t17 = *((unsigned char *)t4);
    t2 = (t0 + 3808U);
    t7 = *((char **)t2);
    t11 = (0 + 33U);
    t2 = (t7 + t11);
    t18 = *((unsigned char *)t2);
    t19 = (t17 == t18);
    if (t19 == 0)
        goto LAB40;

LAB41:    xsi_set_current_line(166, ng0);
    t2 = (t0 + 9750);
    xsi_report(t2, 25U, (unsigned char)0);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t17 = *((unsigned char *)t4);
    t2 = (t0 + 3808U);
    t7 = *((char **)t2);
    t11 = (0 + 34U);
    t2 = (t7 + t11);
    t18 = *((unsigned char *)t2);
    t19 = (t17 == t18);
    if (t19 == 0)
        goto LAB42;

LAB43:    xsi_set_current_line(169, ng0);
    t2 = (t0 + 9795);
    xsi_report(t2, 25U, (unsigned char)0);
    xsi_set_current_line(171, ng0);
    t2 = (t0 + 2472U);
    t4 = *((char **)t2);
    t17 = *((unsigned char *)t4);
    t2 = (t0 + 3808U);
    t7 = *((char **)t2);
    t11 = (0 + 35U);
    t2 = (t7 + t11);
    t18 = *((unsigned char *)t2);
    t19 = (t17 == t18);
    if (t19 == 0)
        goto LAB44;

LAB45:    xsi_set_current_line(172, ng0);
    t2 = (t0 + 9840);
    xsi_report(t2, 25U, (unsigned char)0);
    xsi_set_current_line(174, ng0);
    t2 = (t0 + 2632U);
    t4 = *((char **)t2);
    t17 = *((unsigned char *)t4);
    t2 = (t0 + 3808U);
    t7 = *((char **)t2);
    t11 = (0 + 36U);
    t2 = (t7 + t11);
    t18 = *((unsigned char *)t2);
    t19 = (t17 == t18);
    if (t19 == 0)
        goto LAB46;

LAB47:    xsi_set_current_line(175, ng0);
    t2 = (t0 + 9885);
    xsi_report(t2, 25U, (unsigned char)0);
    xsi_set_current_line(177, ng0);
    t2 = (t0 + 2792U);
    t4 = *((char **)t2);
    t17 = *((unsigned char *)t4);
    t2 = (t0 + 3808U);
    t7 = *((char **)t2);
    t11 = (0 + 37U);
    t2 = (t7 + t11);
    t18 = *((unsigned char *)t2);
    t19 = (t17 == t18);
    if (t19 == 0)
        goto LAB48;

LAB49:    xsi_set_current_line(178, ng0);
    t2 = (t0 + 9930);
    xsi_report(t2, 25U, (unsigned char)0);
    xsi_set_current_line(180, ng0);
    t3 = (170 * 1000LL);
    t2 = (t0 + 4848);
    xsi_process_wait(t2, t3);

LAB52:    *((char **)t1) = &&LAB53;
    goto LAB1;

LAB21:    goto LAB20;

LAB23:    goto LAB21;

LAB24:    t15 = (t0 + 9640);
    xsi_report(t15, 19U, 2);
    goto LAB25;

LAB26:    t12 = 0;

LAB29:    if (t12 < 8U)
        goto LAB30;
    else
        goto LAB28;

LAB30:    t8 = (t4 + t12);
    t14 = (t2 + t12);
    if (*((unsigned char *)t8) != *((unsigned char *)t14))
        goto LAB27;

LAB31:    t12 = (t12 + 1);
    goto LAB29;

LAB32:    t15 = (t0 + 9685);
    xsi_report(t15, 19U, 2);
    goto LAB33;

LAB34:    t12 = 0;

LAB37:    if (t12 < 8U)
        goto LAB38;
    else
        goto LAB36;

LAB38:    t8 = (t4 + t12);
    t14 = (t2 + t12);
    if (*((unsigned char *)t8) != *((unsigned char *)t14))
        goto LAB35;

LAB39:    t12 = (t12 + 1);
    goto LAB37;

LAB40:    t8 = (t0 + 9730);
    xsi_report(t8, 19U, 2);
    goto LAB41;

LAB42:    t8 = (t0 + 9775);
    xsi_report(t8, 19U, 2);
    goto LAB43;

LAB44:    t8 = (t0 + 9820);
    xsi_report(t8, 19U, 2);
    goto LAB45;

LAB46:    t8 = (t0 + 9865);
    xsi_report(t8, 19U, 2);
    goto LAB47;

LAB48:    t8 = (t0 + 9910);
    xsi_report(t8, 19U, 2);
    goto LAB49;

LAB50:    goto LAB14;

LAB51:    goto LAB50;

LAB53:    goto LAB51;

LAB55:    t2 = (t0 + 9955);
    xsi_report(t2, 9U, (unsigned char)0);
    goto LAB56;

LAB57:    goto LAB2;

LAB58:    goto LAB57;

LAB60:    goto LAB58;

}


extern void work_a_1003049348_2372691052_init()
{
	static char *pe[] = {(void *)work_a_1003049348_2372691052_p_0,(void *)work_a_1003049348_2372691052_p_1};
	xsi_register_didat("work_a_1003049348_2372691052", "isim/encodercllg_tb_isim_beh.exe.sim/work/a_1003049348_2372691052.didat");
	xsi_register_executes(pe);
}
