/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "H:/D DRIVE/encodercllg/encoder1.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_2540846514_1035706684(char *, char *, char *, char *, int );
char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_1942683869_3212880686_p_0(char *t0)
{
    char t9[16];
    char t10[16];
    char t11[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t12;
    unsigned int t13;
    char *t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned int t21;

LAB0:    xsi_set_current_line(326, ng0);
    t1 = (t0 + 1312U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3152);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(327, ng0);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t3 = (t0 + 3232);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t4, 9U);
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(328, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t1 = (t0 + 4984U);
    t4 = ieee_p_1242562249_sub_2540846514_1035706684(IEEE_P_1242562249, t10, t3, t1, 1);
    t5 = (t0 + 5052);
    t7 = (t11 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 8;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t12 = (8 - 0);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t13;
    t8 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t9, t4, t10, t5, t11);
    t14 = (t9 + 12U);
    t13 = *((unsigned int *)t14);
    t15 = (1U * t13);
    t2 = (9U != t15);
    if (t2 == 1)
        goto LAB5;

LAB6:    t16 = (t0 + 3296);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t8, 9U);
    xsi_driver_first_trans_fast(t16);
    xsi_set_current_line(329, ng0);
    t1 = (t0 + 1672U);
    t3 = *((char **)t1);
    t13 = (8 - 7);
    t15 = (t13 * 1U);
    t21 = (0 + t15);
    t1 = (t3 + t21);
    t4 = (t0 + 3360);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB3;

LAB5:    xsi_size_not_matching(9U, t15, 0);
    goto LAB6;

}


extern void work_a_1942683869_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1942683869_3212880686_p_0};
	xsi_register_didat("work_a_1942683869_3212880686", "isim/encodercllg_tb_isim_beh.exe.sim/work/a_1942683869_3212880686.didat");
	xsi_register_executes(pe);
}
